-- Курсовая работы по предмету СУБД MySQL

-- Тема: "База данных цеха изготовления деталей"

drop database if exists workshop;
create database workshop;
use workshop;


-- 1. Создание таблицы areas (участки - структурные подразделения цеха)
drop table if exists areas;
create table areas(
	id serial primary key COMMENT 'НОМЕР УЧАСТКА', -- Номер участка (BIGINT unsigned not null auto_increment unique)
	description varchar(255), -- Описание работы участка
	location int unsigned not null COMMENT 'ЭТАЖ' -- Расположение участка (этаж)
	-- head_master varchar(255) -- Старший мастер участка
);


-- 2. Создание таблицы employees (все относящиеся к цеху работники) 
drop table if exists employees;
create table employees(
	id serial primary key, -- Номер работника (BIGINT unsigned not null auto_increment unique)
	firstname varchar(100),
	lastname varchar(100),
	area_id BIGINT unsigned not null COMMENT 'ПРИНАДЛЕЖНОСТЬ К ОПРЕДЕЛЕННОМУ УЧАСТКУ',
	position varchar(100) COMMENT 'ДОЛЖНОСТЬ',
	hiring year, -- Год приема на работу
	age int unsigned not null,
	special_status varchar(100), -- Осообый статус работника (молодой специалист, ветеран)
	foreign key(area_id) references areas(id) on update cascade on delete cascade
);


-- 3. Создание таблицы equipment (оборудование, находящееся в цехе)
drop table if exists equipment;
create table equipment(
	id serial primary key, -- BIGINT unsigned not null auto_increment unique
	title varchar(100) COMMENT 'НАЗВАНИЕ ОБОРУДОВАНИЯ С МОДЕЛЬЮ',
	purpose varchar(255) COMMENT 'ОСНОВНОЕ НАЗНАЧЕНИЕ ОБОРУДОВАНИЯ',
	type_equipment ENUM('токарный', 'фрезерный', 'шлифовальный', 'резьбонарезной', 'слесарный', 'прочее'),
	cnc bool COMMENT 'НАЛИЧИЕ СИСТЕМЫ ЧПУ НА СТАНКЕ',
	area_id BIGINT unsigned not null COMMENT 'ПРИНАДЛЕЖНОСТЬ К ОПРЕДЕЛЕННОМУ УЧАСТКУ',
	operator_id BIGINT unsigned not null COMMENT 'ОПЕРАТОР СТАНКА',
	`status` ENUM('in work', 'downtime', 'on repair'), -- downtime - подразумевается простой, когда нет работы
	maintainance_date date COMMENT 'ДАТА ПОСЛЕДНЕГО ТЕХНИЧЕСКОГО ОБСЛУЖИВАНИЯ СТАНКА',
	foreign key(area_id) references areas(id) on update cascade on delete cascade,
	foreign key(operator_id) references employees(id) on update cascade on delete cascade
);


-- 4. Создание таблицы tools_pantry (инструментальные кладовые в цехе)
drop table if exists tools_pantry;
create table tools_pantry(
	id serial primary key, -- BIGINT unsigned not null auto_increment unique
	description varchar(255) COMMENT 'ОПИСАНИЕ ИНСТРУМЕНТАЛЬНОЙ КЛАДОВОЙ'
);


-- 5. Создание таблицы tools (инструмент в цехе и его нахождение в инструментальных кладовых)
drop table if exists tools;
create table tools(
	id serial primary key, -- BIGINT unsigned not null auto_increment unique
	tool varchar(255) COMMENT 'НАЗВАНИЕ ИНСТРУМЕНТА',
	type_tool ENUM('токарный', 'фрезерный', 'шлифовальный', 'резьбонарезной', 'слесарный', 'прочее'),
	balance int unsigned COMMENT 'ДОСТУПНОЕ КОЛИЧЕСТВО',
	tool_pantry_id bigint unsigned not null COMMENT 'НОМЕР ИНСТРУМЕНТАЛЬНОЙ КЛАДОВОЙ, ГДЕ НАХОДИТСЯ ИНСТРУМЕНТ',
	foreign key (tool_pantry_id) references tools_pantry(id) on update cascade on delete cascade
);


-- Связь М-М с таблицей areas делаем через вспомогательную таблицу tools_areas
-- 6. Создание таблицы tools_areas
-- Один инструмент может быть выдан любом участку и любой участок может получить один инструмент
drop table if exists tools_areas;
create table tools_areas(
	tool_id BIGINT unsigned not null,
	area_id BIGINT unsigned not null,
	primary key (tool_id, area_id), -- составной
	foreign key (tool_id) references tools_pantry(id) on update cascade on delete cascade,
	foreign key (area_id) references areas(id) on update cascade on delete cascade
);	


-- 7. Создание таблицы details (детали, обрабатываемые в цехе)
drop table if exists details;
create table details(
	id serial primary key, -- BIGINT unsigned not null auto_increment unique
	part_number int, -- шифр детали
	title varchar(255) COMMENT 'НАЗВАНИЕ ДЕТАЛИ',
	difficult tinyint COMMENT 'ГРУППА СЛОЖНОСТИ ДЕТАЛИ', -- чем больше цифра, тем деталь сложнее в обработке
	area_id BIGINT unsigned not null COMMENT 'ПРИНАДЛЕЖНОСТЬ К ОПРЕДЕЛЕННОМУ УЧАСТКУ',
	quantity int unsigned COMMENT 'КОЛИЧЕСТВО ДЕТАЛЕЙ В ОБРАБОТКЕ',
	foreign key(area_id) references areas(id) on update cascade on delete cascade
);


-- 8. Создание таблицы weekly_basis (недельное задание на изготовление деталей)
drop table if exists weekly_basis;
create table weekly_basis(
	id serial primary key, -- BIGINT unsigned not null auto_increment unique
	part_number_id BIGINT unsigned not null,
	term date COMMENT 'СРОК НА ИЗГОТОВЛЕНИЕ',
	foreign key(part_number_id) references details(id) on update cascade on delete cascade
);


-- 9. Создание таблицы control (бюро технического контроля цехов)
drop table if exists control;
create table control(
	id serial primary key, -- BIGINT unsigned not null auto_increment unique
	description varchar(255),
	area_id BIGINT unsigned not null COMMENT 'ПРИНАДЛЕЖНОСТЬ К ОПРЕДЕЛЕННОМУ УЧАСТКУ',
	head_controller varchar(255), -- Старший контролер БТК
	foreign key control(area_id) references areas(id) on update cascade on delete cascade
);


-- 10. Создание таблицы repair (журнал ремонта оборудования)
drop table if exists repair;
create table repair(
	id serial primary key, -- BIGINT unsigned not null auto_increment unique
	equipment_id BIGINT unsigned not null COMMENT 'НОМЕР ОБОРУДОВАНИЯ',
	description varchar(255) COMMENT 'ОПИСАНИЕ ПОЛОМКИ ОБОРУДОВАНИЯ',
	date_of_breakdown date COMMENT 'ДАТА ВЫХОДА ИЗ СТРОЯ',
	date_of_repair date COMMENT 'ДАТА ВВОДА В РАБОТУ',
	foreign key(equipment_id) references equipment(id) on update cascade on delete cascade
);


-- 11. Создание таблицы rests (ежегодные отпуска работников)
drop table if exists rests;
create table rests(
	employee_id serial primary key, -- BIGINT unsigned not null auto_increment unique
	start_rest date COMMENT 'ДАТА НАЧАЛА ОТПУСКА',
	finish_rest date COMMENT 'ДАТА ОКОНЧАНИЯ ОТПУСКА',
	foreign key(employee_id) references employees(id) on update cascade on delete cascade
);


-- 12. Создание таблицы defective (описание перечня забракованых деталей и причин)
drop table if exists defective;
create table defective(
	id serial primary key, -- BIGINT unsigned not null auto_increment unique
	detail_id BIGINT unsigned not null COMMENT 'ШИФР ДЕТАЛИ',
	description varchar(255) COMMENT 'ОПИСАНИЕ ПРИЧИН БРАКА',
	control_id BIGINT unsigned not null COMMENT 'БТК, ОБНАРУЖЕВШЕЕ БРАК',
	foreign key(detail_id) references details(id) on update cascade on delete cascade,
	foreign key(control_id) references control(id) on update cascade on delete cascade
);
