-- Задачи по курсовой работе

-- 1.	Скрипты характерных выборок (включающие группировки, JOIN'ы, вложенные таблицы) (6-8)
-- 1.1 Вывести список всех деталей, срок изготовления которых до 31.01.22 включительно
-- Используем таблицы details, weakly_basis
select
	d.id,
	d.part_number,
	wb.term 
from details d join weekly_basis wb on d.id = wb.part_number_id 
where wb.term <= '2022-01-31' -- устанавливаем крайний срок
order by wb.term; -- сортируем по сроку для понимания ключевых дат


-- 1.2 Вывести всех сотрудников, у которых отпуск выпадал на июль 2021 года
-- employees, rests
select 
	e.id,
	e.firstname,
	e.lastname
from employees e 
where e.id in (select r.employee_id from rests r where (r.start_rest >= '2021-07-01' and r.finish_rest <= '2021-09-30'));


-- 1.3 Вывести общим списком фамилии всех работников цеха с учетом главных контролеров участков
-- employees, control
(select
	e.lastname 
from employees e
order by e.lastname) -- выбираем фамилии основных работников
union
(select
	c.head_controller 
from control c
order by c.head_controller); -- выбираем фамилии главных контролеров


-- 1.4 Вывести количество станков по каждой группе
select
	e.type_equipment as 'тип оборудования',
	count(*) as 'количество станков в группе, шт'
from equipment e 
group by e.type_equipment 
order by count(*) desc; 


-- 1.5 Вывести номер участка, с которого поступило наибольшее количество деталей с браком
-- defective, details
select 
	d.area_id,
	a.description, 
	count(*) as 'количество деталей с браком, шт'
from details d join defective d2 on d.id = d2.detail_id join areas a on a.id = d.area_id 
group by d.area_id
order by count(*) desc limit 1; 


-- 1.6 Вывести номера участков, где есть молодые специалисты
-- employees, areas
select 
	a.id as 'Номер участка',
	count(*) as 'Количество молодых специалистов' 
from areas a 
where a.id in (select e.area_id from employees e where e.special_status = 'Молодой специалист')
group by a.id;


-- 1.7 Вывести оборудование, которое ломалось (с учетом количества поломок)
-- repair, equipment
select 
	r.equipment_id,
	e.title, 
	e.type_equipment, 
	count(*) as 'Количество поломок'
from `repair` r join equipment e on e.id = r.equipment_id
group by r.equipment_id
order by count(*) desc;


-- 1.8 Вывести основные и оборотные средства одной таблицей (инструмент и оборудование)
select
	e.title 
from equipment e 
union
select
	t.tool 
from tools t;


-- 1.9 Только оборудование с системой ЧПУ (столбик cnc таблицы equipment)
select 
	e.title
from equipment e 
where e.cnc = 1
order by e.title;



-- 1.10 Вывести название оборудования, ремонт которого не завершен на данный момент
-- repair, equipment
select 
	e.title as 'Оборудование в ремонте',
	r.date_of_breakdown as 'Начало простоя',
	(current_date() - r.date_of_breakdown) as 'Количество дней простоя'
from `repair` r join equipment e on r.equipment_id = e.id 
where r.date_of_repair is null;



-- 1.11 Вывести группу оборудования, станки из которой больше всего ломались
-- repair, equipment
select 
	e.type_equipment as 'группа оборудования',
	count(*) as 'количество поломок оборудования группы'
from equipment e where e.id in (select r.equipment_id from `repair` r)
group by e.type_equipment limit 1; 
 



-- 2.	Представления (2-4)
-- 2.1 Создадим представление, которое выводит всех пенсионеров из таблицы employees
create or replace view retiree as
select 
	e.firstname,
	e.lastname,
	e.age
from employees e 
where e.special_status = 'Пенсионер'
order by e.age;

select * from retiree;


-- 2.2 Создадим представление, которое выводит названия станков с их поломками
create or replace view breakdowns as
select
	e.title as 'Станок',
	r.description as 'Описание поломки'	
from `repair` r join equipment e on r.equipment_id = e.id 
order by e.title;

select * from breakdowns;


-- 2.3 Создадим представление, которое выводит токарный инструмент в количестве менее 250 штук
-- (инструмента мало - пришло время заказывать)
create or replace view tools_limit as
select
	t.tool as 'Инструмент',
	t.balance as 'Остаток на складе, шт'
from tools t 
where t.balance < 250 and t.type_tool = 'токарный'
order by t.balance; 

select * from tools_limit;


-- 2.4 Создадим представление, которое будет выводить детали, срок изготовления которых 3 месяца с текущей даты
create or replace view term_up_to_3 as
select
	d.part_number as 'Шифр детали',
	wb.term as 'Срок изготовления',
	d.quantity as 'Количество, шт'
from weekly_basis wb join details d on wb.part_number_id = d.id
where timestampdiff(month, current_date(), wb.term) < 3
order by wb.term;

select * from term_up_to_3;




-- 3.	Хранимые процедуры / триггеры (2-4)
-- 3.1 Создадим процедуру для вывода количества работников выше определенного возраста
drop procedure if exists after_age;
delimiter //
create procedure after_age(in age int)
begin
	select 
		count(*)
	from employees e 
	where e.age >= age;	
end//
delimiter ;

call after_age(25); -- вывести количество работников старше 25 лет
call after_age(50); -- вывести количество работников старше 50 лет


-- 3.2 Создадим процедуру вывода имен и фамилий операторов, работающих на станках с ЧПУ
drop procedure if exists cnc_operator;
delimiter //
create procedure cnc_operator()
begin
	select 
		e.firstname,
		e.lastname 
	from employees e join equipment eq on e.id = eq.operator_id 
	where eq.cnc = 1
	order by e.firstname;
end
delimiter ;

call cnc_operator(); 


-- 3.3 Создадим триггер запрета изменения сроков изготовления деталей на NULL в таблице weekly_basis
-- (срок всегда должен быть указан)
drop trigger if exists decline_terms;
delimiter //
create trigger decline_terms before update on weekly_basis 
for each row 
begin 
	if new.term is null 
	then signal sqlstate '45000' set message_text = 'Update canceled. You must insert not null date';
	end if;
end//
delimiter ;

-- Команда для проверки работы триггера (срабатывает)
update weekly_basis 
SET 
	term = NULL 
WHERE 
	id = 2;


-- 3.4 Создадим триггер на автоматическую установку статуса "Молодой специалист" при возрасте до 25 лет и годе приема не позднее 2019
drop trigger if exists young_spec;
delimiter //
create trigger young_spec before insert on employees 
for each row 
begin 
	if new.age <= 25 and new.hiring >= '2019' 
	then set new.special_status = 'Молодой специалист';
	end if;
end//
delimiter ;

-- Команда для проверки работы триггера (срабатывает)
insert ignore into employees (firstname, lastname, area_id, position, hiring, age)
values
	('Василий', 'Теркин', 1, 'слесарь', '2020', 23);















